AHIA Follow Android starter project

This project builds a DEBUG APK automatically with GitHub Actions.
It contains the black/blue tiger splash screen and a START button.
The button currently shows a welcome message only; no follower service,
payments, login, order system, or backend is connected.

HOW TO BUILD FREE:
1. Extract this ZIP.
2. Open your GitHub repository (the one you created for AHIA Follow).
3. Upload all files and folders inside this ZIP to the repository root.
4. Commit the upload to the main branch.
5. Open the repository's Actions tab.
6. Select "Build AHIA Follow APK" if shown, then press "Run workflow".
   A push to main/master also starts the build automatically.
7. Wait for the green successful run, open it, and download
   "AHIA-Follow-debug-APK" under Artifacts.
8. Extract the downloaded artifact ZIP to get app-debug.apk.

This is a debug APK for testing, not a Play Store release-signed APK.
